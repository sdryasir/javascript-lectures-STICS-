let btnSubmit = document.getElementById('btnSubmit');
btnSubmit.addEventListener('click', function (a) {
    a.preventDefault();
    vlaidate();
})

function vlaidate() {
    let username = document.getElementById('username').value;
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;

    if (username == '') {
        document.getElementById('username').classList.add('error')
    }
    if (email == '') {
        document.getElementById('email').classList.add('error')
    }
    if (password == '') {
        document.getElementById('password').classList.add('error')
    }
}